<?php
include'../data.php';
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
ini_set('serialize_precision', 14); 
ini_set('precision', 14);
http_response_code(200);
 
 // show products data in json format
 echo json_encode($stoffe,JSON_UNESCAPED_SLASHES);


?>